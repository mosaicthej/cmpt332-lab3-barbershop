Barbershop problem with Semaphores 
